# NOYON-A Android starter

Native Kotlin Android project with a dark galaxy/pink UI, Home/Chat/Voice/Agent/Settings navigation, file picker and explicit Accessibility settings entry. The user's supplied anime-girl image is included in `app/src/main/res/drawable-nodpi/voice_girl.jpg` and displayed on Home and Voice screens.

Developer profile image URL provided by the user: https://i.ibb.co/5gzzzNDD/1000012900.jpg. The remote photo has not been embedded as the launcher icon because its image bytes were not available in the current workspace. Please add the actual developer photo file to generate a matching launcher icon.

## Build APK
Push this folder to a new GitHub repository named `NOYON-A`. The GitHub Actions workflow builds a debug APK on push or when manually run from Actions. Download it from the workflow run's Artifacts section.

## Important limitations
This is a UI starter, not yet a complete AI agent. Gemini/Groq chat requests, API-key settings/storage, natural speech/TTS, true rigged 3D animation, and functional phone actions are not implemented yet. The girl image is currently a 2D image, not a rigged 3D model. Android permissions must be granted by the user; an app cannot silently grant itself all permissions or control every phone function.

Never commit API keys into the repository.
