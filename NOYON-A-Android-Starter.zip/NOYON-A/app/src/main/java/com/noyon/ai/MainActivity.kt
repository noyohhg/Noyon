package com.noyon.ai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 9, 29)
    private val panel = Color.rgb(29, 22, 53)
    private val pink = Color.rgb(255, 112, 202)
    private val purple = Color.rgb(161, 105, 255)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var current = "Home"

    private fun shape(color: Int, r: Float = 24f) = GradientDrawable().apply { setColor(color); cornerRadius = r }
    private fun text(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun gap(h: Int = 12) { content.addView(View(this), LinearLayout.LayoutParams(1, h)) }
    private fun actionButton(s: String, fn: () -> Unit) = TextView(this).apply {
        text = s; textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        setPadding(15, 13, 15, 13); background = shape(Color.rgb(76, 48, 119), 20f); setOnClickListener { fn() }
    }
    private fun card(title: String, desc: String, click: () -> Unit) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 15, 16, 15); background = shape(panel, 22f) }
        c.addView(text(title, 17f, Color.WHITE, true)); c.addView(text(desc, 12f, Color.rgb(196, 184, 219)))
        c.setOnClickListener { click() }; val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 10; content.addView(c, lp)
    }
    private fun render(page: String) {
        current = page
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 10); setBackgroundColor(bg) }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("✦  NOYON-A", 23f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(actionButton("⚙") { render("Settings") }, LinearLayout.LayoutParams(52, 46)); root.addView(header)
        val scroll = ScrollView(this); content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }; scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        when (page) { "Home" -> home(); "Chat" -> chat(); "Voice" -> voice(); "Settings" -> settings(); "Agent" -> agent() }
        val nav = LinearLayout(this).apply { background = shape(Color.rgb(24, 19, 44), 22f); gravity = Gravity.CENTER; setPadding(2, 6, 2, 4) }
        listOf("⌂\nHome", "💬\nChat", "◉\nVoice", "✧\nAgent", "⚙\nSettings").forEach { item ->
            val name = item.substringAfter("\n"); val v = TextView(this).apply { text = item; textSize = 12f; gravity = Gravity.CENTER; setTextColor(if (name == page) pink else Color.LTGRAY); setPadding(2, 8, 2, 8); setOnClickListener { render(name) } }
            nav.addView(v, LinearLayout.LayoutParams(0, 52, 1f))
        }
        root.addView(nav); setContentView(root)
    }
    private fun home() {
        content.addView(text("তোমার নিজের AI সঙ্গী ✨", 23f, Color.WHITE, true)); content.addView(text("Chat • Voice • Coding • Files", 13f, Color.LTGRAY)); gap(16)
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(15, 25, 15, 25); background = shape(Color.rgb(39, 24, 69), 30f) }
        val orb = ImageView(this).apply {
            setImageResource(com.noyon.ai.R.drawable.voice_girl)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = shape(Color.rgb(76, 44, 113), 150f)
            clipToOutline = true
        }
        hero.addView(orb, LinearLayout.LayoutParams(230, 230)); val name = text("NOYON-A", 22f, Color.WHITE, true); name.gravity = Gravity.CENTER; hero.addView(name)
        val sub = text("Tap to start your conversation", 12f, Color.rgb(211, 190, 241)); sub.gravity = Gravity.CENTER; hero.addView(sub)
        hero.setOnClickListener { render("Chat") }; content.addView(hero, LinearLayout.LayoutParams(-1, -2)); gap(14)
        val row = LinearLayout(this)
        listOf("💬  Chat" to "Chat", "🎙  Voice" to "Voice").forEach { p -> val b = actionButton(p.first) { render(p.second) }; val lp = LinearLayout.LayoutParams(0, -2, 1f); lp.marginEnd = 6; row.addView(b, lp) }; content.addView(row); gap()
        card("📁  Upload files & code", "ফাইল/ছবি নির্বাচন করে চ্যাটে পাঠানোর UI", { render("Chat") })
        card("📱  Phone Agent", "নিজে Accessibility অনুমতি চালু করে supported actions ব্যবহার", { render("Agent") })
    }
    private fun chat() {
        content.addView(text("Chat with NOYON-A", 23f, Color.WHITE, true)); content.addView(text("API সেট করলে AI উত্তর দিতে পারবে।", 13f, Color.LTGRAY)); gap()
        val bubble = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 14, 14, 14); background = shape(panel, 20f) }
        bubble.addView(text("হাই! আমি NOYON-A। Gemini/Groq API সেট করে আমার সাথে কথা বলো, কোড লেখাও এবং ফাইল বিশ্লেষণ করো।", 15f)); content.addView(bubble); gap(12)
        val input = EditText(this).apply { hint = "এখানে মেসেজ বা কোড লেখো…"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); minLines = 3; gravity = Gravity.TOP; setPadding(14, 12, 14, 12); background = shape(Color.rgb(35, 27, 58), 18f) }
        content.addView(input); gap(8)
        val row = LinearLayout(this)
        row.addView(actionButton("＋ File") { chooseFile() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(View(this), LinearLayout.LayoutParams(7, 1))
        row.addView(actionButton("➤ Send") { Toast.makeText(this, "API Settings যোগ করে Chat API সংযুক্ত করতে হবে।", Toast.LENGTH_LONG).show() }, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(row); gap(12)
        card("API Settings", "Gemini / Groq provider configuration", { render("Settings") })
    }
    private fun voice() {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(10, 24, 10, 24) }
        val top = text("VOICE MODE", 13f, pink, true); top.gravity = Gravity.CENTER; wrap.addView(top); gap(18)
        val avatar = ImageView(this).apply {
            setImageResource(com.noyon.ai.R.drawable.voice_girl)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = shape(Color.rgb(88, 47, 139), 200f)
            clipToOutline = true
        }
        wrap.addView(avatar, LinearLayout.LayoutParams(260, 260))
        val title = text("বল, আমি শুনছি…", 22f, Color.WHITE, true); title.gravity = Gravity.CENTER; wrap.addView(title)
        val note = text("Natural voice API সংযুক্ত করলে voice chat চালু হবে।", 12f, Color.LTGRAY); note.gravity = Gravity.CENTER; wrap.addView(note)
        val b = actionButton("Microphone permission") { requestMic() }; val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = 20; wrap.addView(b, lp); content.addView(wrap)
    }
    private fun settings() {
        content.addView(text("Settings", 26f, Color.WHITE, true)); gap()
        card("👤  Developer Profile", "Developer: Noyon • Profile photo: https://i.ibb.co/5gzzzNDD/1000012900.jpg • Join Channel", { open("https://t.me/allhackfree288") })
        card("🔑  API Settings", "Gemini API key • Groq API key • Model selection", { Toast.makeText(this, "API configuration screen is a starter placeholder.", Toast.LENGTH_LONG).show(); open("https://aistudio.google.com/app/apikey") })
        card("🎙  Voice", "Speech permission ও voice provider", { requestMic() })
        card("🛡  Phone permissions", "Accessibility settings খুলে নিজে অনুমতি দাও", { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        card("🌌  Theme", "Galaxy Purple + Pink glow", { Toast.makeText(this, "Galaxy theme active", Toast.LENGTH_SHORT).show() })
        card("ℹ  About", "NOYON-A • Version 1.0 starter", { Toast.makeText(this, "AI API ও animated 3D model এখনো সংযুক্ত নয়।", Toast.LENGTH_LONG).show() })
    }
    private fun agent() {
        content.addView(text("Phone Agent", 24f, Color.WHITE, true)); content.addView(text("Android নিরাপত্তার কারণে সব ফোনের সবকিছু স্বয়ংক্রিয়ভাবে করা যায় না।", 13f, Color.LTGRAY)); gap()
        card("Enable Accessibility", "নিজে চালু করো; অনুমতি ছাড়া ফোন নিয়ন্ত্রণ হবে না", { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        card("App Permissions", "NOYON-A-এর app settings", { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) })
    }
    private fun chooseFile() { val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }; startActivityForResult(i, 42) }
    private fun requestMic() { if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 7) else Toast.makeText(this, "Microphone permission available", Toast.LENGTH_SHORT).show() }
    private fun open(url: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor = bg; window.navigationBarColor = bg; render("Home") }
}
