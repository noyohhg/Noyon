package com.noyon.ai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** Accessibility entry point. Android requires the user to enable this service manually. */
class PhoneControlService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* User-approved actions are added here. */ }
    override fun onInterrupt() {}
}
